package com.example.ridwan.biodata.presenter;

public interface ILoginActivity {

    void chekInputan();
    void masuk();
    boolean cekPassword(String Password);
    boolean cekUser(String Username);

}
