package com.example.ridwan.biodata.presenter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.example.ridwan.biodata.R;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
    }
}
